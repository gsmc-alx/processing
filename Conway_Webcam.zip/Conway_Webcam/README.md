Idea for Valentina's installation.
